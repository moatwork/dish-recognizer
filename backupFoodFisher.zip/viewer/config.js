//
// Edit this file and update the settings
//

// Refresh interval in seconds
const REFRESH_INTERVAL = 10;

// Probably don't change this
const CONTAINER = 'photo-out'
